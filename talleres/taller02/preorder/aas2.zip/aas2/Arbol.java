public abstract class Arbol {
}
