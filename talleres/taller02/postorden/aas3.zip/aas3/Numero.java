public class Numero extends Arbol {

    private int valor;
    
    public Numero(int valor) {
	
	this.valor = valor;
    }

    public int obtValor() {

	return this.valor;
    }
			     
}
